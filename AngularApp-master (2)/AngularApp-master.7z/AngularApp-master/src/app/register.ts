export class Register {
    userName:string;
    password:string;
    userId:string
}
